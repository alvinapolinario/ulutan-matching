'use strict';
const os = require('os');
const path = require('path');
const { createApp } = require('./src/app');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));

let ctx;
try {
  ctx = createApp({ dataDir: DATA_DIR, secureCookies: process.env.SECURE_COOKIES === 'true' });
} catch (e) {
  console.error('\nCould not start:', e.message, '\n');
  process.exit(1);
}

ctx.server.listen(PORT, HOST, () => {
  const addrs = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  console.log('\nTapad-Tapad / Ulutan system is running.');
  console.log(`  This computer:  http://localhost:${PORT}`);
  for (const a of addrs) console.log(`  LAN:            http://${a}:${PORT}   (TV: http://${a}:${PORT}/display)`);
  console.log(`  Data folder:    ${DATA_DIR}\n`);
});

function shutdown(sig) {
  console.log(`\n${sig} received, shutting down...`);
  try { ctx.store.backupIfDirty(); } catch (_) { /* ignore */ }
  ctx.io.close();
  ctx.server.close(() => { ctx.store.close(); process.exit(0); });
  setTimeout(() => { ctx.store.close(); process.exit(0); }, 3000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

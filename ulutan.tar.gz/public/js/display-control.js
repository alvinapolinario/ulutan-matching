(function () {
  'use strict';
  const { api, ev, esc, toast, pad, pts } = App;
  const $ = (id) => document.getElementById(id);
  let state = null;
  let busy = false;

  const fightBlock = (m, big) => m ? `
    <div class="d-flex align-items-center gap-3 flex-wrap">
      <div class="${big ? 'display-6' : 'fs-4'} fw-bold">#${pad(m.fightNumber)}</div>
      <div class="flex-fill p-2 rounded" style="background:var(--red-soft)"><div class="small fw-bold" style="color:var(--red)">RED</div>
        <div class="fw-bold">${esc(m.red.entryName)}</div><div class="lb ${big ? 'fs-3' : ''}">${esc(m.red.legband)}</div></div>
      <div class="fw-bold text-muted">VS</div>
      <div class="flex-fill p-2 rounded" style="background:var(--blue-soft)"><div class="small fw-bold" style="color:var(--blue)">BLUE</div>
        <div class="fw-bold">${esc(m.blue.entryName)}</div><div class="lb ${big ? 'fs-3' : ''}">${esc(m.blue.legband)}</div></div>
    </div>` : '<div class="text-muted">None</div>';

  function render() {
    const s = state;
    $('currentBox').innerHTML = s.current ? fightBlock(s.current, true) : '<div class="text-muted">No current fight selected. Press “Next fight →” to start with the first fight in the queue.</div>';
    const c = s.current;
    if (c && c.status === 'CONFIRMED') {
      $('resultBox').innerHTML = `<div class="d-flex gap-2 flex-wrap align-items-center">
        <span class="small fw-bold me-1">Result:</span>
        <button class="btn btn-danger" data-result="RED">Red wins · 1–0</button>
        <button class="btn btn-secondary" data-result="DRAW">Draw · ½–½</button>
        <button class="btn btn-primary" data-result="BLUE">Blue wins · 0–1</button>
        <div class="form-check ms-2"><input class="form-check-input" type="checkbox" id="advanceAfter" checked><label class="form-check-label small" for="advanceAfter">then go to next fight</label></div></div>`;
    } else if (c && c.status === 'COMPLETED') {
      $('resultBox').innerHTML = `<div class="alert alert-success py-2 mb-0">Result recorded: <b>${pts(c.redPoints)} – ${pts(c.bluePoints)}</b> (${{ RED: 'Red wins', BLUE: 'Blue wins', DRAW: 'Draw' }[c.result]})</div>`;
    } else $('resultBox').innerHTML = '';
    $('nextBox').innerHTML = fightBlock(s.next, false);
    $('publishedSwitch').checked = s.published;
    if (document.activeElement !== $('upcomingCount')) $('upcomingCount').value = s.upcomingCount;
    $('remaining').textContent = `${s.remaining} pending after current`;
    loadQueue();
  }

  async function loadQueue() {
    const list = (await api('GET', ev('/matches?status=CONFIRMED'))).filter((m) => !m.isCurrent);
    $('queueRows').innerHTML = list.length ? list.map((m) => `<tr>
      <td class="fw-bold">#${pad(m.fightNumber)}</td>
      <td class="row-red">${esc(m.red.entryName)} <span class="lb">${esc(m.red.legband)}</span></td>
      <td class="row-blue">${esc(m.blue.entryName)} <span class="lb">${esc(m.blue.legband)}</span></td>
      <td class="text-end"><button class="btn btn-sm btn-outline-warning" data-current="${m.id}">Set current</button></td></tr>`).join('')
      : '<tr><td colspan="4" class="text-muted">Queue is empty.</td></tr>';
  }

  async function load() { state = await api('GET', ev('/display-state')); render(); }
  const reload = () => load().catch((e) => toast(e.message, 'danger'));

  async function act(fn, okMsg) {
    if (busy) return;
    busy = true;
    try { const s = await fn(); if (s && s.eventId) { state = s; render(); } else reload(); if (okMsg) toast(okMsg); } catch (e) { toast(e.message, 'danger'); } finally { busy = false; }
  }

  $('nextBtn').onclick = () => act(() => api('POST', ev('/display/advance'), { direction: 'next' }));
  $('backBtn').onclick = () => act(() => api('POST', ev('/display/advance'), { direction: 'back' }));
  $('publishedSwitch').onchange = (e) => act(() => api('PATCH', ev('/display'), { published: e.target.checked }), e.target.checked ? 'TV now shows the fights.' : 'TV shows “Please stand by”.');
  $('saveUpcoming').onclick = () => act(() => api('PATCH', ev('/display'), { upcomingCount: Number($('upcomingCount').value) }), 'Saved.');
  $('refreshBtn').onclick = () => act(() => api('POST', ev('/display/refresh')), 'All TV screens told to reload.');
  $('resultBox').addEventListener('click', (e) => {
    const b = e.target.closest('[data-result]'); if (!b || !state.current) return;
    const advance = $('advanceAfter') ? $('advanceAfter').checked : false;
    act(() => api('POST', ev(`/matches/${state.current.id}/result`), { result: b.dataset.result, advance }), `Result saved for Fight #${pad(state.current.fightNumber)}.`);
  });
  $('queueRows').addEventListener('click', (e) => {
    const b = e.target.closest('[data-current]'); if (!b) return;
    act(() => api('POST', ev('/display/current'), { matchId: Number(b.dataset.current) }));
  });
  App.live({ onChange: (msg) => { if (msg.state) { state = msg.state; render(); } else reload(); }, onResync: reload });
  reload();
})();

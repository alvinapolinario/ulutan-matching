'use strict';
const { badRequest, notFound, EVENT_STATUSES, EVENT_TRANSITIONS, now, cleanText } = require('../lib/common');
const { addAudit, bumpVersion } = require('./audit');

function createEventService(store, bus) {
  function parseSettings(input, isCreate) {
    const out = {};
    if (isCreate || input.name !== undefined) {
      out.name = cleanText(input.name, 120);
      if (!out.name) throw badRequest('Event name is required.');
    }
    if (isCreate || input.date !== undefined) {
      out.date = cleanText(input.date, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(out.date)) throw badRequest('Event date must be YYYY-MM-DD.');
    }
    if (isCreate || input.venue !== undefined) out.venue = cleanText(input.venue, 160);
    if (isCreate || input.startingFightNumber !== undefined) {
      const n = Number(input.startingFightNumber ?? 1);
      if (!Number.isInteger(n) || n < 1 || n > 9999) throw badRequest('Starting fight number must be between 1 and 9999.');
      out.startingFightNumber = n;
    }
    if (isCreate || input.maxLegbands !== undefined) {
      const n = Number(input.maxLegbands ?? 500);
      if (!Number.isInteger(n) || n < 2 || n > 999) throw badRequest('Maximum legbands must be between 2 and 999.');
      out.maxLegbands = n;
    }
    if (isCreate || input.fightNumberMode !== undefined) {
      out.fightNumberMode = input.fightNumberMode === undefined ? 'DRAW' : String(input.fightNumberMode).toUpperCase();
      if (!['DRAW', 'AUTO'].includes(out.fightNumberMode)) throw badRequest('Fight number mode must be DRAW (bunot) or AUTO.');
    }
    if (input.upcomingCount !== undefined) {
      const n = Number(input.upcomingCount);
      if (!Number.isInteger(n) || n < 0 || n > 20) throw badRequest('Upcoming fights on TV must be between 0 and 20.');
      out.upcomingCount = n;
    }
    return out;
  }

  const svc = {
    list: () => [...store.data.events].sort((a, b) => b.id - a.id),
    get(id) {
      const ev = store.data.events.find((e) => e.id === Number(id));
      if (!ev) throw notFound('Event not found.');
      return ev;
    },
    find: (id) => store.data.events.find((e) => e.id === Number(id)) || null,
    defaultEvent() {
      const open = svc.list().filter((e) => e.status !== 'ARCHIVED');
      return open[0] || svc.list()[0] || null;
    },

    create(input, userId) {
      const s = parseSettings(input, true);
      return store.transaction((d) => {
        const ev = {
          id: store.nextId(d, 'event'),
          name: s.name, date: s.date, venue: s.venue,
          status: 'DRAFT',
          fightNumberMode: s.fightNumberMode,
          startingFightNumber: s.startingFightNumber,
          nextFightNumber: s.startingFightNumber,
          nextEntryNumber: 1,
          nextLegbandNumber: 1,
          maxLegbands: s.maxLegbands,
          legbandWidth: 3,
          stateVersion: 1,
          display: { currentMatchId: null, published: true, upcomingCount: s.upcomingCount ?? 8 },
          createdBy: userId, createdAt: now(), updatedAt: now(),
        };
        d.events.push(ev);
        addAudit(store, d, { eventId: ev.id, entity: 'event', entityId: ev.id, action: 'EVENT_CREATED', newValues: s, userId });
        return ev;
      });
    },

    update(id, input, userId) {
      const s = parseSettings(input, false);
      const ev = store.transaction((d) => {
        const e = d.events.find((x) => x.id === Number(id));
        if (!e) throw notFound('Event not found.');
        const usedFights = d.matches.some((m) => m.eventId === e.id);
        const old = {};
        for (const k of Object.keys(s)) {
          if (k === 'upcomingCount') { old[k] = e.display.upcomingCount; e.display.upcomingCount = s[k]; continue; }
          old[k] = e[k];
          if (k === 'startingFightNumber') {
            if (usedFights && s[k] !== e[k]) throw badRequest('Starting fight number cannot change after matches exist.');
            e.nextFightNumber = s[k];
          }
          if (k === 'maxLegbands' && s[k] < e.nextLegbandNumber - 1) throw badRequest(`Maximum legbands cannot be below the ${e.nextLegbandNumber - 1} already issued.`);
          e[k] = s[k];
        }
        e.updatedAt = now();
        bumpVersion(d, e.id);
        addAudit(store, d, { eventId: e.id, entity: 'event', entityId: e.id, action: 'EVENT_UPDATED', oldValues: old, newValues: s, userId });
        return e;
      });
      bus.publish(ev.id, 'event:updated', { eventId: ev.id });
      return ev;
    },

    setStatus(id, status, userId) {
      if (!EVENT_STATUSES.includes(status)) throw badRequest('Invalid event status.');
      const ev = store.transaction((d) => {
        const e = d.events.find((x) => x.id === Number(id));
        if (!e) throw notFound('Event not found.');
        if (e.status === status) return e;
        if (!EVENT_TRANSITIONS[e.status].includes(status)) {
          throw badRequest(`Cannot change event from ${e.status} to ${status}. Allowed: ${EVENT_TRANSITIONS[e.status].join(', ')}.`);
        }
        const old = e.status;
        e.status = status;
        e.updatedAt = now();
        bumpVersion(d, e.id);
        addAudit(store, d, { eventId: e.id, entity: 'event', entityId: e.id, action: 'EVENT_STATUS_CHANGED', oldValues: { status: old }, newValues: { status }, userId });
        return e;
      });
      bus.publish(ev.id, 'event:updated', { eventId: ev.id });
      return ev;
    },
  };
  return svc;
}

module.exports = { createEventService };
